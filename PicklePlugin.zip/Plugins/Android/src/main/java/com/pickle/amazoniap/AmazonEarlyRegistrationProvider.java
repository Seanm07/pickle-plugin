package com.pickle.amazoniap;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;

import com.amazon.device.iap.PurchasingListener;
import com.amazon.device.iap.PurchasingService;
import com.amazon.device.iap.model.ProductDataResponse;
import com.amazon.device.iap.model.PurchaseResponse;
import com.amazon.device.iap.model.PurchaseUpdatesResponse;
import com.amazon.device.iap.model.UserDataResponse;

// Registered as a <provider> in AndroidManifest.xml so Android constructs it (and runs
// onCreate) before Application.onCreate() and before any Activity — earlier than any Unity
// C# code can execute. Its only job is to make PurchasingService.registerListener() install
// the SDK's ActivityLifecycleCallbacks before the main Activity's first onResume, which is
// otherwise missed in a Unity app (registerListener from C# happens after that first resume,
// so the SDK never sees a resume event and every purchase queues forever in
// ForegroundTaskPipeline until the app is backgrounded and foregrounded).
//
// AmazonIapBridge.Initialize() still calls registerListener() again later from C# with the
// real listener — the SDK keeps a single listener reference and swaps it in place without
// re-installing the lifecycle hook, so this placeholder only needs to exist long enough to
// win the timing race.
public class AmazonEarlyRegistrationProvider extends ContentProvider {

    private static final PurchasingListener NO_OP_LISTENER = new PurchasingListener() {
        @Override public void onUserDataResponse(UserDataResponse response) { }
        @Override public void onProductDataResponse(ProductDataResponse response) { }
        @Override public void onPurchaseResponse(PurchaseResponse response) { }
        @Override public void onPurchaseUpdatesResponse(PurchaseUpdatesResponse response) { }
    };

    @Override
    public boolean onCreate() {
        Context context = getContext();
        if (context != null) {
            try {
                PurchasingService.registerListener(context, NO_OP_LISTENER);
            } catch (Throwable t) {
                // Never let a startup-time IAP registration issue take down app launch.
            }
        }
        return true;
    }

    @Override public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) { return null; }
    @Override public String getType(Uri uri) { return null; }
    @Override public Uri insert(Uri uri, ContentValues values) { return null; }
    @Override public int delete(Uri uri, String selection, String[] selectionArgs) { return 0; }
    @Override public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) { return 0; }
}
