using System.Collections.Generic;
using UnityEngine;
#if !NO_FACEBOOK
    using Facebook.Unity;
#endif

public class FacebookManager : MonoBehaviour {
    public static FacebookManager instance;
    
    void Awake() {
        instance = instance ?? this;
        
#if !NO_FACEBOOK
        if (!FB.IsInitialized) {
            FB.Init(OnFacebookInitialised);
        } else {
            FB.ActivateApp();
        }
#endif
    }

    private void OnFacebookInitialised() {
#if !NO_FACEBOOK
        if (FB.IsInitialized) {
            FB.ActivateApp();
        } else {
            Debug.LogError("Failed to initialize the Facebook SDK");
        }
#endif
    }
	
	void OnApplicationPause (bool pauseStatus)
    {
#if !NO_FACEBOOK
        if (!pauseStatus) {
            if (!FB.IsInitialized) {
                FB.Init(OnFacebookInitialised);
            } else {
                FB.ActivateApp();
            }
        }
#endif
    }

    public void LogEvent(string eventName, string contentId, string description = "", Dictionary<string, object> additionalParameters = null) {
#if !NO_FACEBOOK
        if (!FB.IsInitialized)
            return;
        
        Dictionary<string, object> parameters = additionalParameters != null ? additionalParameters : new Dictionary<string, object>();
        
        parameters.Add(AppEventParameterName.ContentID, contentId);
        parameters.Add(AppEventParameterName.Description, description);
        
        FB.LogAppEvent(eventName, parameters: parameters);
#endif
    }
}
