﻿using UnityEngine;
using Firebase.Auth;
using System.Threading.Tasks;
using Firebase.Analytics;
using System;

public class FirebaseAuthManager : MonoBehaviour
{
    // Reference to the firebase auth instance
    public FirebaseAuth auth { get; private set; }
    public FirebaseUser user { get; private set; }
    
    public static event Action<FirebaseUser> OnRegistrationSuccess;
    public static event Action<string> OnRegistrationFailed;

    public static event Action<FirebaseUser> OnLoginSuccess;
    public static event Action<string> OnLoginFailed;

    public static event Action<FirebaseUser> OnLoggedInAccountChanged;
    
    void Awake()
    {
        // Assign the callback reference
        FirebaseManager.OnFirebaseInitialised += FirebaseInitialised;
    }
    
    private static bool IsFirebaseInitialised(Action action) {
        bool isInitialised = FirebaseManager.IsInitialised();
        
        if (!isInitialised)
            FirebaseManager.instance.AddToInitialiseQueue(action);
        
        return isInitialised;
    }

    // Called when firebase has successfully been initialised and analytics is ready for use
    private void FirebaseInitialised()
    {
        FirebaseManager.OnFirebaseInitialised -= FirebaseInitialised;
        
        auth = FirebaseAuth.DefaultInstance;

        AuthStateChanged(this, null);
        auth.StateChanged += AuthStateChanged;
    }

    public static void RegisterAccount(string email, string password)
    {
        // If firebase isn't initialised yet then this function call is queued and re-called when it is
        if (!IsFirebaseInitialised(() => RegisterAccount(email, password))) return;
        
        FirebaseManager.instance.authManager.auth.CreateUserWithEmailAndPasswordAsync(email, password).ContinueWith(task =>
        {
            FirebaseAnalyticsManager.LogEvent(FirebaseAnalytics.EventSignUp, task.Status.ToString());
            
            switch (task.Status)
            {
                case TaskStatus.Canceled:
                    Debug.LogError("Registration cancelled!");
                    
                    // Enqueue the callback to be called on the main thread
                    UnityMainThreadDispatcher.instance.Enqueue(() => OnRegistrationFailed?.Invoke("Cancelled"));
                    break;
                
                case TaskStatus.Faulted:
                    Debug.LogError("Registration failed! Error: " + task.Exception?.ToString());
                    
                    FirebaseAnalyticsManager.LogError("RegisterAccount - " + task.Exception?.ToString());
                    
                    // Enqueue the callback to be called on the main thread
                    UnityMainThreadDispatcher.instance.Enqueue(() => OnRegistrationFailed?.Invoke("Failed with error: " + task.Exception));
                    break;
                
                default:
                    // Enqueue the callback to be called on the main thread
                    UnityMainThreadDispatcher.instance.Enqueue(() => OnRegistrationSuccess?.Invoke(task.Result));
                    break;
            }
        });
    }

    public static void LoginAccount(string email, string password)
    {
        // If firebase isn't initialised yet then this function call is queued and re-called when it is
        if (!IsFirebaseInitialised(() => LoginAccount(email, password))) return;
        
        FirebaseManager.instance.authManager.auth.SignInWithEmailAndPasswordAsync(email, password).ContinueWith(task =>
        {
            FirebaseAnalyticsManager.LogEvent(FirebaseAnalytics.EventLogin, task.Status.ToString());
            
            switch (task.Status)
            {
                case TaskStatus.Canceled:
                    Debug.LogError("Login cancelled!");

                    // Enqueue the callback to be called on the main thread
                    UnityMainThreadDispatcher.instance.Enqueue(() => OnLoginFailed?.Invoke("Cancelled"));
                    break;
                
                case TaskStatus.Faulted:
                    Debug.LogError("Login failed! Error: " + task.Exception?.ToString());
                    
                    FirebaseAnalyticsManager.LogError("LoginAccount - " + task.Exception?.ToString());
                    
                    // Enqueue the callback to be called on the main thread
                    UnityMainThreadDispatcher.instance.Enqueue(() => OnLoginFailed?.Invoke("Failed with error: " + task.Exception));
                    break;
                
                default:
                    // Enqueue the callback to be called on the main thread
                    UnityMainThreadDispatcher.instance.Enqueue(() => OnLoginSuccess?.Invoke(task.Result));
                    break;
            }
        });
    }
    
    private void AuthStateChanged(object sender, EventArgs eventArgs)
    {
        // Check if the current user is different to the user variable we have stored
        if (auth.CurrentUser != user)
        {
            user = auth.CurrentUser;
            
            OnLoggedInAccountChanged?.Invoke(auth.CurrentUser);
        }
    }
}
