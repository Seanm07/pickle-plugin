﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Firebase.Database;
using UnityEngine;

public class FirebaseDatabaseManager : MonoBehaviour
{
    public DatabaseReference database { get; private set; }
    
    public static event Action<string, DataSnapshot> OnDatabaseGetActionComplete;
    public static event Action<string, string> OnDatabaseGetActionFailed;

    public static event Action<string, DataSnapshot> OnDatabaseSubscriptionChildAdded;
    public static event Action<string, DataSnapshot> OnDatabaseSubscriptionChildRemoved;
    public static event Action<string, DataSnapshot> OnDatabaseSubscriptionChildChanged;
    
    public static event Action<string> OnDatabaseSetActionComplete;
    public static event Action<string, string> OnDatabaseSetActionFailed;

    public static event Action<string> OnDatabaseIncrementActionComplete;

    public string databaseName = "gamepickle-projects";

    private static bool isDatabaseConnectionInitialised = false;
    
    void Awake()
    {
        // Assign the callback reference
        FirebaseManager.OnFirebaseInitialised += FirebaseInitialised;
    }

    private static bool IsFirebaseInitialised() {
        bool isInitialised = FirebaseManager.IsInitialised() && FirebaseManager.instance.databaseManager.database != null;
        
        if(FirebaseManager.instance.debugMode)
            Debug.Log("isInitialised returned " + isInitialised);
        
        return isInitialised;
    }
    
    private static bool IsFirebaseInitialised(Action action) {
        bool isInitialised = FirebaseManager.IsInitialised();
        
        if(FirebaseManager.instance.debugMode)
            Debug.Log("isInitialised returned " + isInitialised);
        
        if (!isInitialised)
            FirebaseManager.instance.AddToInitialiseQueue(action);
        
        return isInitialised;
    }
    
    // Called when firebase has successfully been initialised and analytics is ready for use
    private void FirebaseInitialised()
    { 
        FirebaseManager.OnFirebaseInitialised -= FirebaseInitialised;
    }

    private void InitialiseDatabaseConnection() {
        Debug.Log("Initialising database connection..");
        
        // Required to use the database in the editor
        FirebaseManager.instance.app.Options.DatabaseUrl = new Uri(FirebaseManager.instance.databaseURL);
        
        // Only required if the database has a security policy configured which needs P12 security details
        //FirebaseManager.instance.app.SetEditorP12FileName(FirebaseManager.instance.databaseP12FileName);
        //FirebaseManager.instance.app.SetEditorServiceAccountEmail(FirebaseManager.instance.databaseServiceAccountEmail);
        //FirebaseManager.instance.app.SetEditorP12Password(FirebaseManager.instance.databaseP12Password);

        database = FirebaseDatabase.DefaultInstance.RootReference; //FirebaseDatabase.GetInstance(FirebaseManager.instance.app).GetReference(databaseName);

        isDatabaseConnectionInitialised = true;
    }

    public static void Get(string referenceKey, string[] dbPath) {
        // If firebase isn't initialised yet then this function call is queued and re-called when it is
        if (!IsFirebaseInitialised(() => Get(referenceKey, dbPath))) return;
        
        if (!isDatabaseConnectionInitialised) FirebaseManager.instance.databaseManager.InitialiseDatabaseConnection();
        
        DatabaseReference dbRef = FirebaseManager.instance.databaseManager.GetDatabaseRef(dbPath);
        
        if(FirebaseManager.instance.debugMode)
            Debug.Log("Sending database GET request for ref " + referenceKey);
        
        dbRef.GetValueAsync().ContinueWith(task =>
        {
            switch (task.Status)
            {
                case TaskStatus.Canceled:
                    Debug.LogError("Get database data cancelled!");
                    
                    // Enqueue the callback to be called on the main thread
                    UnityMainThreadDispatcher.instance.Enqueue(() => OnDatabaseGetActionFailed?.Invoke(referenceKey, "Cancelled"));
                    break;
                
                case TaskStatus.Faulted:
                    Debug.LogError("Get database data failed! Error: " + task.Exception?.ToString());
                    
                    FirebaseAnalyticsManager.LogError("Get - " + task.Exception?.ToString());
                    
                    // Enqueue the callback to be called on the main thread
                    UnityMainThreadDispatcher.instance.Enqueue(() => OnDatabaseGetActionFailed?.Invoke(referenceKey, "Failed with error: " + task.Exception));
                    break;
                
                default:
                    if(FirebaseManager.instance.debugMode)
                        Debug.Log("Database GET for ref " + referenceKey + " was successful");
                    
                    // Enqueue the callback to be called on the main thread
                    UnityMainThreadDispatcher.instance.Enqueue(() => OnDatabaseGetActionComplete?.Invoke(referenceKey, task.Result));
                    break;
            }
        });
    }

    public static EventHandler<ChildChangedEventArgs> SubscribeToChildAdded(string referenceKey, string[] dbPath, Action<string, string[], ChildChangedEventArgs> childAdded) {
        // Don't bother to queue this function to be called again if firebase is not initialised as it needs to return a value
        if (!IsFirebaseInitialised()) return null;

        if (!isDatabaseConnectionInitialised) FirebaseManager.instance.databaseManager.InitialiseDatabaseConnection();
        
        DatabaseReference dbRef = FirebaseManager.instance.databaseManager.GetDatabaseRef(dbPath);
        
        if(FirebaseManager.instance.debugMode)
            Debug.Log("Sending database subscribe to child added event for ref " + referenceKey);

        EventHandler<ChildChangedEventArgs> childAddedAction = (sender, args) => childAdded(referenceKey, dbPath, args);
        
        dbRef.ChildAdded += childAddedAction;

        return childAddedAction;
    }
    
    public static EventHandler<ChildChangedEventArgs> SubscribeToChildRemoved(string referenceKey, string[] dbPath, Action<string, string[], ChildChangedEventArgs> childRemoved) {
        // Don't bother to queue this function to be called again if firebase is not initialised as it needs to return a value
        if (!IsFirebaseInitialised()) return null;

        if (!isDatabaseConnectionInitialised) FirebaseManager.instance.databaseManager.InitialiseDatabaseConnection();
        
        DatabaseReference dbRef = FirebaseManager.instance.databaseManager.GetDatabaseRef(dbPath);
        
        if(FirebaseManager.instance.debugMode)
            Debug.Log("Sending database subscribe to child removed event for ref " + referenceKey);

        EventHandler<ChildChangedEventArgs> childRemovedAction = (sender, args) => childRemoved(referenceKey, dbPath, args);
        
        dbRef.ChildRemoved += childRemovedAction;

        return childRemovedAction;
    }
    
    public static EventHandler<ChildChangedEventArgs> SubscribeToChildChanged(string referenceKey, string[] dbPath, Action<string, string[], ChildChangedEventArgs> childChanged) {
        // Don't bother to queue this function to be called again if firebase is not initialised as it needs to return a value
        if (!IsFirebaseInitialised()) return null;

        if (!isDatabaseConnectionInitialised) FirebaseManager.instance.databaseManager.InitialiseDatabaseConnection();
        
        DatabaseReference dbRef = FirebaseManager.instance.databaseManager.GetDatabaseRef(dbPath);
        
        if(FirebaseManager.instance.debugMode)
            Debug.Log("Sending database subscribe to child changed event for ref " + referenceKey);

        EventHandler<ChildChangedEventArgs> childChangedAction = (sender, args) => childChanged(referenceKey, dbPath, args);
        
        dbRef.ChildChanged += childChangedAction;

        return childChangedAction;
    }


    public static void UnsubscribeFromChildAdded(string referenceKey, string[] dbPath, EventHandler<ChildChangedEventArgs> childAddedEvent) {
        // If firebase isn't initialised yet then this function call is queued and re-called when it is
        if (!IsFirebaseInitialised(() => UnsubscribeFromChildAdded(referenceKey, dbPath, childAddedEvent))) return;

        if (!isDatabaseConnectionInitialised) FirebaseManager.instance.databaseManager.InitialiseDatabaseConnection();
        
        DatabaseReference dbRef = FirebaseManager.instance.databaseManager.GetDatabaseRef(dbPath);
        
        if(FirebaseManager.instance.debugMode)
            Debug.Log("Sending database unsubscribe from child added event for ref " + referenceKey);

        dbRef.ChildAdded -= childAddedEvent;
    }
    
    public static void UnsubscribeFromChildRemoved(string referenceKey, string[] dbPath, EventHandler<ChildChangedEventArgs> childRemovedEvent) {
        // If firebase isn't initialised yet then this function call is queued and re-called when it is
        if (!IsFirebaseInitialised(() => UnsubscribeFromChildAdded(referenceKey, dbPath, childRemovedEvent))) return;

        if (!isDatabaseConnectionInitialised) FirebaseManager.instance.databaseManager.InitialiseDatabaseConnection();
        
        DatabaseReference dbRef = FirebaseManager.instance.databaseManager.GetDatabaseRef(dbPath);
        
        if(FirebaseManager.instance.debugMode)
            Debug.Log("Sending database unsubscribe from child removed event for ref " + referenceKey);

        dbRef.ChildAdded -= childRemovedEvent;
    }
    
    public static void UnsubscribeFromChildChanged(string referenceKey, string[] dbPath, EventHandler<ChildChangedEventArgs> childChangedEvent) {
        // If firebase isn't initialised yet then this function call is queued and re-called when it is
        if (!IsFirebaseInitialised(() => UnsubscribeFromChildAdded(referenceKey, dbPath, childChangedEvent))) return;

        if (!isDatabaseConnectionInitialised) FirebaseManager.instance.databaseManager.InitialiseDatabaseConnection();
        
        DatabaseReference dbRef = FirebaseManager.instance.databaseManager.GetDatabaseRef(dbPath);
        
        if(FirebaseManager.instance.debugMode)
            Debug.Log("Sending database unsubscribe from child changed event for ref " + referenceKey);

        dbRef.ChildAdded -= childChangedEvent;
    }

    public static void Set(string referenceKey, string[] dbPath, System.Object newValue)
    {
        // If firebase isn't initialised yet then this function call is queued and re-called when it is
        if (!IsFirebaseInitialised(() => Set(referenceKey, dbPath, newValue))) return;
        
        if (!isDatabaseConnectionInitialised) FirebaseManager.instance.databaseManager.InitialiseDatabaseConnection();
        
        DatabaseReference dbRef = FirebaseManager.instance.databaseManager.GetDatabaseRef(dbPath);

        dbRef.SetValueAsync(newValue).ContinueWith(task =>
        {
            switch (task.Status)
            {
                case TaskStatus.Canceled:
                    Debug.LogError("Set database data cancelled!");
                    
                    // Enqueue the callback to be called on the main thread
                    UnityMainThreadDispatcher.instance.Enqueue(() => OnDatabaseSetActionFailed?.Invoke(referenceKey, "Cancelled"));
                    break;
                
                case TaskStatus.Faulted:
                    Debug.LogError("Set database data failed! Error: " + task.Exception?.ToString());
                    
                    FirebaseAnalyticsManager.LogError("Set - " + task.Exception?.ToString());
                    
                    // Enqueue the callback to be called on the main thread
                    UnityMainThreadDispatcher.instance.Enqueue(() => OnDatabaseSetActionFailed?.Invoke(referenceKey, "Failed with error: " + task.Exception?.ToString()));
                    break;
                
                default:
                    // Enqueue the callback to be called on the main thread
                    UnityMainThreadDispatcher.instance.Enqueue(() => OnDatabaseSetActionComplete?.Invoke(referenceKey));
                    break;
            }
        });
    }

    public static void SetMultiple(string referenceKey, string[] dbPath, string[] keys, System.Object[] values)
    {
        // If firebase isn't initialised yet then this function call is queued and re-called when it is
        if (!IsFirebaseInitialised(() => SetMultiple(referenceKey, dbPath, keys, values))) return;
        
        if (!isDatabaseConnectionInitialised) FirebaseManager.instance.databaseManager.InitialiseDatabaseConnection();
        
        Dictionary<string, System.Object> childUpdates = new Dictionary<string, System.Object>();

        for (int i = 0; i < keys.Length; i++)
            childUpdates.Add(keys[i], values[i]);

        SetMultiple(referenceKey, dbPath, childUpdates);
    }
    
    public static void SetMultiple(string referenceKey, string[] dbPath, Dictionary<string, System.Object> childUpdates)
    {
        // If firebase isn't initialised yet then this function call is queued and re-called when it is
        if (!IsFirebaseInitialised(() => SetMultiple(referenceKey, dbPath, childUpdates))) return;
        
        if (!isDatabaseConnectionInitialised) FirebaseManager.instance.databaseManager.InitialiseDatabaseConnection();
        
        DatabaseReference dbRef = FirebaseManager.instance.databaseManager.GetDatabaseRef(dbPath);

        dbRef.UpdateChildrenAsync(childUpdates).ContinueWith(task =>
        {
            switch (task.Status)
            {
                case TaskStatus.Canceled:
                    Debug.LogError("Set multiple database data cancelled!");
                    
                    UnityMainThreadDispatcher.instance.Enqueue(() => OnDatabaseSetActionFailed?.Invoke(referenceKey, "Cancelled"));
                    break;
                
                case TaskStatus.Faulted:
                    Debug.LogError("Set multiple database data failed! Error: " + task.Exception?.ToString());
                    
                    FirebaseAnalyticsManager.LogError("Set multiple - " + task.Exception?.ToString());
                    
                    UnityMainThreadDispatcher.instance.Enqueue(() => OnDatabaseSetActionFailed?.Invoke(referenceKey, "Failed with error: " + task.Exception));
                    break;
                
                default:
                    UnityMainThreadDispatcher.instance.Enqueue(() => OnDatabaseSetActionComplete?.Invoke(referenceKey));
                    break;
            }
        });
    }

    public static void IncrementValues(string referenceKey, string[] dbPath, Dictionary<string, int> childIncrements) {
        // If firebase isn't initialised yet then this function call is queued and re-called when it is
        if (!IsFirebaseInitialised(() => IncrementValues(referenceKey, dbPath, childIncrements))) return;
        
        if (!isDatabaseConnectionInitialised) FirebaseManager.instance.databaseManager.InitialiseDatabaseConnection();
        
        DatabaseReference dbRef = FirebaseManager.instance.databaseManager.GetDatabaseRef(dbPath);
        
        if (dbRef != null) {
            // This transaction runs on loop until a connection can be made OR TransactionResult.Abort() is called
            dbRef.RunTransaction(mutableData => {
                if(FirebaseManager.instance.debugMode)
                    Debug.Log("Running transaction for " + referenceKey);
                
                Dictionary<string, object> childData = mutableData.Value as Dictionary<string, object> ?? new Dictionary<string, object>();

                if(FirebaseManager.instance.debugMode)
                    Debug.Log("Requested " + childIncrements.Count + " childIncrements");
                
                foreach (KeyValuePair<string, int> childValues in childIncrements) {
                    // Get the value of the child by the key
                    if (childData.TryGetValue(childValues.Key, out object childValueObject)) {
                        if(FirebaseManager.instance.debugMode)
                            Debug.Log("childValue key is " + childValues.Key);
                        
                        // Convert the child value to an int and refer to it as the serversideValue
                        if (int.TryParse(childValueObject.ToString(), out int serversideValue)) {
                            if(FirebaseManager.instance.debugMode)
                                Debug.Log("serversideValue: " + serversideValue);

                            int newValue = serversideValue + childValues.Value;
                            
                            childData[childValues.Key] = newValue;

                            if (FirebaseManager.instance.debugMode) {
                                Debug.Log("clientsideValue: " + childValues.Value);

                                Debug.Log("Setting key " + childValues.Key + " to value " + childData[childValues.Key]);
                            }
                        }
                    } else {
                        // Data doesn't exist in database (we may have not grabbed the database data yet, it will re-run if not)
                        childData.Add(childValues.Key, childValues.Value);
                        
                        if(FirebaseManager.instance.debugMode)
                            Debug.Log("childData key not found, adding new key: " + childValues.Key + " with value: " + childValues.Value);
                    }
                }
                
                mutableData.Value = childData;
                
                if(FirebaseManager.instance.debugMode)
                    Debug.Log("Transaction " + referenceKey + " was sent! (This does not necessarily mean the value was successfully updated, check for transaction warning logs)");
                
                return TransactionResult.Success(mutableData);
            });

            UnityMainThreadDispatcher.instance.Enqueue(() => OnDatabaseIncrementActionComplete?.Invoke(referenceKey));
        } else {
            Debug.LogError("dbRef was null! Possible invalid dbPath!");
        }
    }
    
    private DatabaseReference GetDatabaseRef(string[] dbPath) {
        if (FirebaseManager.instance.databaseManager.database == null) {
            Debug.LogError("Unable to get database path as database reference is currently null!");
            return null;
        }
        
        if (!isDatabaseConnectionInitialised) FirebaseManager.instance.databaseManager.InitialiseDatabaseConnection();
        
        DatabaseReference curPath = FirebaseManager.instance.databaseManager.database;

        foreach (string path in dbPath) {
            curPath = curPath.Child(path);

            if (FirebaseManager.instance.debugMode) {
                Debug.Log("Getting child with name: " + path);

                if (curPath == null) {
                    Debug.LogError("curPath is null after going into " + path);
                } else {
                    Debug.Log("curPath is fine, keep going..");
                }
            }
        }

        return curPath;
    }

    public static string DatabaseRefToKey(DatabaseReference reference)
    {
        return reference.ToString().ToLowerInvariant();
    }
    
}
