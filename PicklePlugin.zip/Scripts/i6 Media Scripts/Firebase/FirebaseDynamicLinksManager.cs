﻿using System;
using System.Threading.Tasks;
using UnityEngine;
using Firebase.DynamicLinks;


public class FirebaseDynamicLinksManager : MonoBehaviour
{
    public static event Action<string, Uri> OnGenerateDynamicLinkComplete;
    public static event Action<string, string> OnGenerateDynamicLinkFailed;
    
    void Awake()
    {
        // Assign the callback reference
        FirebaseManager.OnFirebaseInitialised += FirebaseInitialised;

        #if !UNITY_EDITOR
            DynamicLinks.DynamicLinkReceived += DynamicLinkReceived;
        #endif
    }

    private static bool IsFirebaseInitialised(Action action) {
        bool isInitialised = FirebaseManager.IsInitialised();
        
        if (!isInitialised)
            FirebaseManager.instance.AddToInitialiseQueue(action);
        
        return isInitialised;
    }
    
    // Called when firebase has successfully been initialised
    private void FirebaseInitialised()
    {
        FirebaseManager.OnFirebaseInitialised -= FirebaseInitialised;
        
        
    }
    
    public static void GenerateReferralDynamicLink(string referralKey, DynamicLinkPathLength linkLength)
    {
        // If firebase isn't initialised yet then this function call is queued and re-called when it is
        if (!IsFirebaseInitialised(() => GenerateReferralDynamicLink(referralKey, linkLength))) return;
        
        DynamicLinkOptions linkOptions = new DynamicLinkOptions
        {
            PathLength = linkLength
        };

        // The app deep link, used to launch the app if already installed via a custom url scheme (must be setup in the manifest on android and xcode on ios)
        UriBuilder deepLinkTargetUri = new UriBuilder("https://" + FirebaseManager.instance.dynamicLinkBase + "/launch/" + FirebaseManager.instance.uniqueGameIdentifier + "?ref_id=" + FirebaseManager.instance.persistantUserId + "&ref_source=" + referralKey);
        
        // URL the user is taken to on android if the app isn't installed
        UriBuilder androidStoreUri = new UriBuilder("market://details?id=" + FirebaseManager.instance.androidPackageName + "&referrer=utm_source%3Dfirebase_referrer%26utm_campaign%3D" + referralKey);
        //UriBuilder androidStoreUri = new UriBuilder("https://play.google.com/store/apps/details?id=" + FirebaseManager.instance.androidPackageName + "&referrer=utm_source%3Dfirebase_referrer%26utm_campaign%3D" + referralKey);
        
        // URL the user is taken to on iOS if the app isn't installed
        UriBuilder iosStoreUri = new UriBuilder("https://itunes.apple.com/us/app/id" + FirebaseManager.instance.iosAppStoreId);
        
        SocialMetaTagParameters socialMetaTags = new SocialMetaTagParameters {
            Description = "You've been invited to play " + Application.productName + "!",
            Title = Application.productName
        };

        IOSParameters iosParam = new IOSParameters(FirebaseManager.instance.iosPackageName) {
            AppStoreId = FirebaseManager.instance.iosAppStoreId,
            FallbackUrl = iosStoreUri.Uri
        };

        AndroidParameters androidParam = new AndroidParameters(FirebaseManager.instance.androidPackageName) {
            FallbackUrl = androidStoreUri.Uri
        };
        
        DynamicLinkComponents linkComponents = new DynamicLinkComponents(deepLinkTargetUri.Uri, FirebaseManager.instance.dynamicLinkBase) {
            IOSParameters = iosParam,
            AndroidParameters = androidParam,
            SocialMetaTagParameters = socialMetaTags
        };
        
        DynamicLinks.GetShortLinkAsync(linkComponents, linkOptions).ContinueWith(task =>
        {
            #if UNITY_EDITOR
                Debug.Log("Dynamic short link generation not supported in the editor, a long link will be returned instead.");
            #endif
            
            switch (task.Status)
            {
                case TaskStatus.Canceled:
                    Debug.LogError("GetShortLinkAsync cancelled!");
                    
                    // Enqueue the callback to be called on the main thread
                    UnityMainThreadDispatcher.instance.Enqueue(() => OnGenerateDynamicLinkFailed?.Invoke(referralKey, "Cancelled"));
                    break;
                
                case TaskStatus.Faulted:
                    Debug.LogError("GetShortLinkAsync failed! Error: " + task.Exception?.ToString());
                    
                    FirebaseAnalyticsManager.LogError("GetShortLinkAsync - " + task.Exception?.ToString());
                    
                    // Enqueue the callback to be called on the main thread
                    UnityMainThreadDispatcher.instance.Enqueue(() => OnGenerateDynamicLinkFailed?.Invoke(referralKey, "Failed with error: " + task.Exception));
                    break;
                
                default:
                    Debug.Log("Finished with status " + task.Status.ToString());
                    
                    ShortDynamicLink link = task.Result;

                    // Enqueue the callback to be called on the main thread
                    UnityMainThreadDispatcher.instance.Enqueue(() => OnGenerateDynamicLinkComplete?.Invoke(referralKey, link.Url));
                    
                    if (FirebaseManager.instance.debugMode)
                    {
                        // Log any warnings
                        foreach (string warning in link.Warnings)
                            Debug.LogWarning(warning);
                    }
                    break;
            }
        });
    }
    
    private void DynamicLinkReceived(object sender, EventArgs args)
    {
        ReceivedDynamicLinkEventArgs dynamicLinkArgs = args as ReceivedDynamicLinkEventArgs;
        ReceivedDynamicLink dynamicLink = dynamicLinkArgs?.ReceivedDynamicLink;

        if (FirebaseManager.instance.isFirstSession)
            ReferralManager.instance.OnReferralLinkOpened(dynamicLink?.Url.OriginalString);
    }
}
