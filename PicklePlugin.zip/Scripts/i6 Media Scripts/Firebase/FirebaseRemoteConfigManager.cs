﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using UnityEngine;
using Firebase.RemoteConfig;

public class FirebaseRemoteConfigManager : MonoBehaviour
{
    [Serializable]
    public class CustomRemoteConfig
    {
        public string key;
        public string value;
    }
    
    public List<CustomRemoteConfig> config = new List<CustomRemoteConfig>();

    public static event Action<string> OnFetchRemoteConfigFailed;
    public static event Action OnFetchRemoteConfigComplete;

    public static event Action OnRemoteConfigUpdated;
    
    private const string PREF_REMOTE_CONFIG_PREFIX = "firebase_remote_config";

    private FirebaseRemoteConfig remoteConfigInstance;
    
    void Awake()
    {
        LoadRemoteConfigValues();
        
        // Assign the callback reference
        FirebaseManager.OnFirebaseInitialised += FirebaseInitialised;
    }

    private static bool IsFirebaseInitialised(Action action) {
        bool isInitialised = FirebaseManager.IsInitialised();
        
        if (!isInitialised)
            FirebaseManager.instance.AddToInitialiseQueue(action);
        
        return isInitialised;
    }
    
    // Called when firebase has successfully been initialised
    private void FirebaseInitialised()
    {
        FirebaseManager.OnFirebaseInitialised -= FirebaseInitialised;

        remoteConfigInstance = FirebaseRemoteConfig.GetInstance(FirebaseManager.instance.app);

        remoteConfigInstance.SetDefaultsAsync(GetRemoteConfigAsDictionary()).ContinueWith(task => {
            switch (task.Status) {
                case TaskStatus.Canceled:
                    Debug.LogError("SetDefaultsAsync cancelled!");
                    break;
                
                case TaskStatus.Faulted:
                    Debug.LogError("SetDefaultsAsync failed! Error: " + task.Exception?.ToString());
                    break;
                
                default:
                    // The defaults have been set but now we need to query if these values have been changed in the firebase panel
                    FetchRemoteConfig();
                    break;
            }
        });
    }
    
    private Dictionary<string, object> GetRemoteConfigAsDictionary() {
        Dictionary<string, object> output = new Dictionary<string, object>();
        
        foreach(CustomRemoteConfig configItem in config)
            output.Add(configItem.key, configItem.value);

        return output;
    }

    public static void FetchRemoteConfig()
    {
        // If firebase isn't initialised yet then this function call is queued and re-called when it is
        if (!IsFirebaseInitialised(() => FetchRemoteConfig())) return;
        
        #if UNITY_EDITOR
            // This doesn't work in the editor and just returns Asynchronous operation was not started
            // So just load defaults
            FirebaseManager.instance.remoteConfigManager.UpdateRemoteConfigValues();
            return;
        #endif
        
        FirebaseManager.instance.remoteConfigManager.remoteConfigInstance.FetchAsync().ContinueWith(task =>
        {
            switch (task.Status) {
                case TaskStatus.Canceled:
                    Debug.LogError("Fetch remote config cancelled!");
                    
                    // Enqueue the callback to be called on the main thread
                    UnityMainThreadDispatcher.instance.Enqueue(() => OnFetchRemoteConfigFailed?.Invoke("Cancelled"));
                    break;
                
                case TaskStatus.Faulted:
                    Debug.LogError("Fetch remote config failed! Error: " + task.Exception?.ToString());
                    
                    FirebaseAnalyticsManager.LogError("Fetch remote - " + task.Exception?.ToString());
                    
                    // Enqueue the callback to be called on the main thread
                    UnityMainThreadDispatcher.instance.Enqueue(() => OnFetchRemoteConfigFailed?.Invoke("Failed with error: " + task.Exception));
                    break;
                
                default:
                    FirebaseManager.instance.remoteConfigManager.UpdateRemoteConfigValues();
                    
                    // Enqueue the callback to be called on the main thread
                    UnityMainThreadDispatcher.instance.Enqueue(() => OnFetchRemoteConfigComplete?.Invoke());
                    break;
            }
        });
    }

    private void UpdateRemoteConfigValues() {
        remoteConfigInstance.ActivateAsync().ContinueWith(task =>
        {
            switch (task.Status) {
                case TaskStatus.Canceled:
                    Debug.LogError("ActivateAsync cancelled!");
                    break;
                
                case TaskStatus.Faulted:
                    Debug.LogError("ActivateAsync failed! Error: " + task.Exception?.ToString());
                    break;
                
                default:
                    foreach (CustomRemoteConfig configItem in config) {
#if !UNITY_EDITOR
                        configItem.value = remoteConfigInstance.GetValue(configItem.key).StringValue;
#endif
                
                        PlayerPrefs.SetString(PREF_REMOTE_CONFIG_PREFIX + configItem.key, configItem.value);
                
                        if(FirebaseManager.instance.debugMode)
                            Debug.Log("Loaded config key " + configItem.key + " as " + configItem.value);
                    }

                    UnityMainThreadDispatcher.instance.Enqueue(() => OnRemoteConfigUpdated?.Invoke());
                    break;
            }
        });
    }

    private void LoadRemoteConfigValues() {
        foreach (CustomRemoteConfig configItem in config)
            configItem.value = PlayerPrefs.GetString(PREF_REMOTE_CONFIG_PREFIX + configItem.key, configItem.value);
    }

    public string GetConfigValue(string key) {
        foreach(CustomRemoteConfig configItem in config)
            if (configItem.key == key)
                return configItem.value;

        Debug.LogError("Unknown config key " + key);
        
        return string.Empty;
    }
    
}
