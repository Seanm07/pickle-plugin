﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Text.RegularExpressions;
using Firebase.Database;
using Firebase.DynamicLinks;
using RestSharp.Contrib;
using UnityEngine;

public class ReferralManager : MonoBehaviour
{
    public static ReferralManager instance;
    
    [Serializable]
    public class ReferralData
    {
        public string key;
        public Uri link;
    }
    
    // Each referral link placement is tracked separately to allow us to see which referral source players are sharing from most
    public List<ReferralData> referralLinks = new List<ReferralData>();

    // Storage for total referrals who have installed the app
    public int installedReferrals { get; private set; }
    
    // Database path names, must mast the rule structure setup at https://console.firebase.google.com/u/0/project/gamepickle-projects/database/gamepickle-projects/rules
    private const string DBPATH_USERS = "users";
    private const string DBPATH_REFERRAL_SOURCE = "referral_sources";
    private const string DBPATH_LAST_UPDATE_DATE = "late_updated_date";
    private const string DBPATH_CREATION_PLATFORM = "creation_platform";
    private const string DBPATH_CREATION_LINK_PATH = "creation_link_path";
    private const string DBPATH_REFERRAL_COUNT = "referral_count";
    private const string DBPATH_REFERRAL_INSTALLS = "referral_installs";

    // PlayerPrefs names
    private const string PREF_REFERRAL_PRE = "firebase_referral_";
    private const string PREF_TOTAL_REFERRALS = "firebase_total_referrals";

    // Editor fallback variables used when an action can only be ran on a device
    private const string EDITOR_LINK_PATH = "editor";

    public static event Action OnReferralCountUpdated;

    private bool hasReferralTriggered;
    
    private void Awake()
    {
        instance = instance ?? this;
        
        FirebaseDynamicLinksManager.OnGenerateDynamicLinkComplete += OnLinkGenerationSuccessful;
        FirebaseDynamicLinksManager.OnGenerateDynamicLinkFailed += OnLinkGenerationFailed;

        FirebaseDatabaseManager.OnDatabaseSetActionComplete += OnDatabaseInsertSuccessful;
        FirebaseDatabaseManager.OnDatabaseSetActionFailed += OnDatabaseInsertFailed;

        FirebaseDatabaseManager.OnDatabaseGetActionComplete += OnDatabaseGetSuccessful;
        FirebaseDatabaseManager.OnDatabaseGetActionFailed += OnDatabaseGetFailed;
        
        // Load any previously generated referral links so they can be reused for this player
        // Otherwise new referral links are generated when they're needed
        foreach (ReferralData referralLink in referralLinks)
        {
            // Check if this referral link has already been generated in the past (if so we'll reuse it)
            if (PlayerPrefs.HasKey(PREF_REFERRAL_PRE + referralLink.key))
            {
                // Set the referral link value for this session
                if (!Uri.TryCreate(PlayerPrefs.GetString(PREF_REFERRAL_PRE + referralLink.key), UriKind.Absolute, out referralLink.link))
                {
                    Debug.LogError("Stored firebase referral URL for " + referralLink.key + " was invalid! Clearing from storage..");
                    PlayerPrefs.DeleteKey(PREF_REFERRAL_PRE + referralLink.key);
                }
            }
        }

        // Load the total referrals count just incase we don't have an internet connection or the request fails
        if (PlayerPrefs.HasKey(PREF_TOTAL_REFERRALS))
        {
            installedReferrals = PlayerPrefs.GetInt(PREF_TOTAL_REFERRALS, 0);
            //OnReferralCountUpdated?.Invoke();
        }
    }
    
    public bool IsReferralLinkGenerated(string referralKey)
    {
        return IsValidReferralKey(referralKey) && GetReferralData(referralKey).link != null;
    }

    public bool IsAnyReferralLinkGenerated() {
        foreach (ReferralData referralLink in referralLinks)
            if (PlayerPrefs.HasKey(PREF_REFERRAL_PRE + referralLink.key))
                return true;

        return false;
    }

    public void RequestReferralLink(string referralKey)
    {
        if (IsValidReferralKey(referralKey))
        {
            if (IsReferralLinkGenerated(referralKey))
            {
                OnReferralLinkReady(referralKey, GetReferralData(referralKey).link);
            }
            else {
                ClickLockManager.Instance.ShowClickLock("Generating Invite Link..\n[sup][FFFF00]Hold on![-][/sup]", true);
                
                //MessagePopupManager.Instance.ShowMessage("Generating Referral Link", "Hold on! We're generating a new unique referral link for you to invite your friends with!");
                FirebaseDynamicLinksManager.GenerateReferralDynamicLink(referralKey, DynamicLinkPathLength.Short);
            }
        }
    }

    public void RequestInstalledReferrals(string reference) {
        Debug.Log("Requesting installed referrals for " + reference);
        
        // If the user has never actually generated a referral link then we can safely assume the database will return 0 so don't even bother querying it
        if (IsAnyReferralLinkGenerated()) {
            string[] referralData = { FirebaseManager.instance.GetPathFriendlyIdentifier(), DBPATH_USERS, FirebaseManager.instance.persistantUserId, DBPATH_REFERRAL_SOURCE, "menu", DBPATH_REFERRAL_COUNT};
            
            FirebaseDatabaseManager.Get(reference, referralData);
        } else {
            // Simulate a database result of 0 (null is treated as blank data)
            OnDatabaseGetSuccessful(reference, null);
        }
    }

    private Uri lastGeneratedLink;
    
    public void OpenLastGeneratedLink()
    {
        Application.OpenURL(lastGeneratedLink.ToString());
    }

    private void UpdateInstalledReferralCount(DataSnapshot data)
    {
        int totalReferrals = 0;

        if (data != null && data.Value != null) {
            if (int.TryParse(data.Value.ToString(), out int referralsFromSource))
                totalReferrals += referralsFromSource;
        }

        PlayerPrefs.SetInt(PREF_TOTAL_REFERRALS, totalReferrals);
        installedReferrals = totalReferrals;
        
        OnReferralCountUpdated?.Invoke();
    }
    
    private string GetReferralLinkPathId(string referralKey)
    {
        if (!Application.isEditor)
        {
            Uri referralUri = GetReferralData(referralKey).link;

            return IsValidReferralKey(referralKey) ? Regex.Replace(referralUri.Segments[referralUri.Segments.Length - 1], @"(?:https?:\/\/)?(?:[^?\/\s]+[?\/])(.*)", "") : string.Empty;
        }
        else
        {
            return IsValidReferralKey(referralKey) ? EDITOR_LINK_PATH : string.Empty;
        }
    }
    
    private bool IsValidReferralKey(string referralKey, bool silent = false)
    {
        if (GetReferralData(referralKey) != null)
        {
            // The referralKey was valid in the referralLinks dictionary
            return true;
        }
        
        if(!silent)
            Debug.LogError("Referral key '" + referralKey + "' is invalid! Ensure this referral key has been setup in the referralLinks dictionary in the inspector of ReferralManager!");

        // The referralKey did not exist in the referralLinks dictionary, the developer did not add it to the dictionary in the inspector
        return false;
    }
    
    private ReferralData GetReferralData(string referralKey)
    {
        foreach(ReferralData referralLink in referralLinks)
            if (referralLink.key == referralKey)
                return referralLink;

        return null;
    }

    public void OnReferralLinkOpened(string url) {
        if (hasReferralTriggered) return;
        
        Debug.Log("Referral link opened - " + url);
        
        try {
            UriBuilder uri = new UriBuilder(url);
            NameValueCollection uriParameters = HttpUtility.ParseQueryString(uri.Query);
            string referralId = uriParameters.Get("ref_id");
            string referralSource = uriParameters.Get("ref_source");

            if(FirebaseManager.instance.debugMode)
                Debug.Log("Looking up: " + FirebaseManager.instance.GetPathFriendlyIdentifier() + " / " + DBPATH_USERS + " / " + referralId + " / " + DBPATH_REFERRAL_SOURCE + " / " + referralSource);
            
            string[] referralSourcePath = {FirebaseManager.instance.GetPathFriendlyIdentifier(), DBPATH_USERS, referralId, DBPATH_REFERRAL_SOURCE, referralSource};
            
            //Dictionary<string, object> referralSetupData = new Dictionary<string, object>();
            //referralSetupData.Add("/" + DBPATH_LAST_UPDATE_DATE + "/", FirebaseManager.instance.GetTimestamp());
            //referralSetupData.Add("/" + DBPATH_CREATION_LINK_PATH + "/", GetReferralLinkPathId(referralSource));
            //referralSetupData.Add("/" + DBPATH_CREATION_PLATFORM + "/", Application.platform.ToString());
            //referralSetupData.Add("/" + DBPATH_REFERRAL_COUNT + "/", 1);
        
            // Create a record in the database with the creation date and source of this referral link (inserting both in a single request)
            //FirebaseDatabaseManager.SetMultiple(referralSource, referralSourcePath, referralSetupData);
            
            Dictionary<string, int> referralData = new Dictionary<string, int>();
            referralData.Add(DBPATH_REFERRAL_COUNT, 1);
            
            // Increment the DBPATH_REFERRAL_COUNT value in a separate increment request otherwise we would need to request to GET the value then add 1 to it anyway
            // Sending a single increment requests cuts down on this
            FirebaseDatabaseManager.IncrementValues("credit_referrer", referralSourcePath, referralData);
            
            Debug.Log("Referred by: " + referralId + " from " + referralSource);

            hasReferralTriggered = true;
        } catch (UriFormatException e) {
            Debug.LogError("Invalid referral URI format! " + e.Message);
        }
    }

    ///////// CALLBACKS //////////
    public void OnLinkGenerationSuccessful(string referralKey, Uri url)
    {
        // Store the referral link in PlayerPrefs so it can be re-used in future sessions
        PlayerPrefs.SetString(PREF_REFERRAL_PRE + referralKey, url.ToString());

        // Set the referral link into the dictionary so it can be reused in the current session without needing PLayerPref queries
        GetReferralData(referralKey).link = url;
        
        Debug.Log("Referral link generated successfully for " + referralKey);
        
        // Disabled, referral data is now only added to database once the link has been CLICKED to reduce massive amounts of database requests
        /*string[] referralPath = {FirebaseManager.instance.GetPathFriendlyIdentifier(), DBPATH_USERS, FirebaseManager.instance.persistantUserId, DBPATH_REFERRAL_SOURCE, referralKey};

        Dictionary<string, object> referralData = new Dictionary<string, object>();
        referralData.Add("/" + DBPATH_CREATION_DATE + "/", FirebaseManager.instance.GetTimestamp());
        referralData.Add("/" + DBPATH_CREATION_LINK_PATH + "/", GetReferralLinkPathId(referralKey));
        referralData.Add("/" + DBPATH_CREATION_PLATFORM + "/", Application.platform.ToString());
        referralData.Add("/" + DBPATH_REFERRAL_COUNT + "/", 0);
        
        // Create a record in the database with the creation date and source of this referral link (inserting both in a single request)
        FirebaseDatabaseManager.SetMultiple(referralKey, referralPath, referralData);*/
        
        OnReferralLinkReady(referralKey, url);
        
        ClickLockManager.Instance.HideClickLock();
    }

    private void OnLinkGenerationFailed(string referralKey, string error)
    {
        Debug.LogError("Failed to generate link with error: " + error);
        
        ClickLockManager.Instance.HideClickLock();
        
        MessagePopupManager.Instance.ShowMessage("Invite Link Generation Failed", error);
    }

    private void OnDatabaseInsertSuccessful(string referenceKey)
    {
        switch (referenceKey) {
            case "credit_referrer":
                // We don't need to do anything here
                break;
            
            default:
                // If this isn't true then the database insert is unrelated to referrals or the referral link key isn't refined in the ReferralManager inspector 
                if(IsValidReferralKey(referenceKey, true))
                    OnReferralLinkReady(referenceKey, GetReferralData(referenceKey).link);
                break;
        }
    }
    
    private void OnDatabaseInsertFailed(string referenceKey, string error)
    {
        switch (referenceKey) {
            case "credit_referrer":
                Debug.LogError("Failed to credit referrer with error: " + error);
                break;
            
            default:
                // If this isn't true then the database insert is unrelated to referrals or the referral link key isn't refined in the ReferralManager inspector 
                if(IsValidReferralKey(referenceKey, true))
                    Debug.LogError("Failed to generate link with error: " + error);
                break;
        }
    }

    private void OnDatabaseGetSuccessful(string reference, DataSnapshot data)
    {
        switch (reference)
        {
            case "update_referrals":
                UpdateInstalledReferralCount(data);
                break;
        }
    }

    private void OnDatabaseGetFailed(string reference, string error)
    {
        MessagePopupManager.Instance.ShowMessage("Referral Link Generation Failed!", error);
    }

    private void OnReferralLinkReady(string referralKey, Uri link) {
        lastGeneratedLink = link;
        
        UnityMainThreadDispatcher.instance.Enqueue(() => MessagePopupManager.Instance.OnNoClick());
        UnityMainThreadDispatcher.instance.Enqueue(() => ShareManager.instance.SharePrompt("Hey! Come join me in " + Application.productName + " play for free - " + link, Application.productName + " invitation!", true));
    }
}
