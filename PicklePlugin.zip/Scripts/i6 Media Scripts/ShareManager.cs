﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

public class ShareManager : MonoBehaviour {
    
    public class ScheduledShareAction {
        public string message;
        public string subject;
        public bool forceChooseShareApp;
        public bool doShareAppIcon;

        public ScheduledShareAction(string inMessage, string inSubject, bool inForceChooseShareApp, bool inDoShareAppIcon) {
            message = inMessage;
            subject = inSubject;
            forceChooseShareApp = inForceChooseShareApp;
            doShareAppIcon = inDoShareAppIcon;
        }
    }
    
    public static ShareManager instance;
    
    #if UNITY_IOS
        [System.Runtime.InteropServices.DllImport("__Internal")]
        private static extern void ShowShare(string message, string subject, bool doShareAppIcon = false);
    #elif UNITY_ANDROID
        private bool androidObjectsReady = false;
        
        private AndroidJavaClass unityClass;
        private AndroidJavaObject currentActivity;
        private AndroidJavaObject packageManager;

        private AndroidJavaObject applicationInfo;
        private AndroidJavaObject res;

        private AndroidJavaObject currentContext;
    #endif

    public bool isShareScheduled { get; set; }
    private ScheduledShareAction scheduledShareAction;
    
    void Awake() {
        instance = instance ?? this;
    }

    public void Start() {
        #if !UNITY_EDITOR && UNITY_ANDROID
            try {
                // Get the unity activity & context
                unityClass = new AndroidJavaClass("com.unity3d.player.UnityPlayer");
                currentActivity = unityClass.GetStatic<AndroidJavaObject>("currentActivity");
                packageManager = currentActivity.Call<AndroidJavaObject>("getPackageManager");

                applicationInfo = packageManager.Call<AndroidJavaObject>("getApplicationInfo", Application.identifier, 0);
                res = packageManager.Call<AndroidJavaObject>("getResourcesForApplication", applicationInfo);

                currentContext = currentActivity.Call<AndroidJavaObject>("getApplicationContext");
                
                androidObjectsReady = true;
            } catch (Exception e) {
                // An exception was encountered, we'll probably share without the app icon instead (unless it was generated successfully in the past?)
                Debug.LogError("Failed to get app icon! " + e.Message);

                androidObjectsReady = false;
            }
        #endif
    }

    public void Update() {
        isShareScheduled = false;
        
        if (scheduledShareAction.doShareAppIcon) {
            #if UNITY_ANDROID
                DoSharePromptWithAppIcon(scheduledShareAction.message, scheduledShareAction.subject, scheduledShareAction.forceChooseShareApp);
            #elif UNITY_IOS
                DoSharePromptIOS(scheduledShareAction.message, scheduledShareAction.subject, true);                    
            #endif
        } else {
            #if UNITY_ANDROID
                DoSharePromptAndroid(scheduledShareAction.message, scheduledShareAction.subject, scheduledShareAction.forceChooseShareApp);
            #elif UNITY_IOS
                DoSharePromptIOS(scheduledShareAction.message, scheduledShareAction.subject, false);                    
            #endif
        }
    }

    public void SharePrompt(string message, string subject, bool forceChooseShareApp = true, bool shareAppIcon = true) {
        scheduledShareAction = new ScheduledShareAction(message, subject, forceChooseShareApp, shareAppIcon);
        isShareScheduled = true;
    }
    
    private void DoSharePromptWithAppIcon(string message, string subject, bool forceChooseShareApp = true) {
        #if UNITY_EDITOR
            Debug.Log("A share event was triggered! On an android or iOS device this would trigger system share actions!");
        #elif UNITY_ANDROID
            DoSharePromptAndroid(message, subject, forceChooseShareApp);
        
            // DISABLED: getBitmap doesn't work anymore when API >= 29
            // Need to upgrade to new method of getting an image 
            /*string iconStoreCachePath = Application.persistentDataPath + "/share_icon_cache.png";

            if(androidObjectsReady){
                try {
                    // Get a higher quality icon than the standard 112x112 icon we would've gotten with a standard getApplicationIcon query
                    AndroidJavaObject iconBitmapDrawable = res.Call<AndroidJavaObject>("getDrawableForDensity", applicationInfo.Get<int>("icon"), 640, null);

                    AndroidJavaObject iconBitmap = iconBitmapDrawable.Call<AndroidJavaObject>("getBitmap");
                    AndroidJavaObject iconByteArrayStream = new AndroidJavaObject("java.io.ByteArrayOutputStream");
                    AndroidJavaClass bitmapCompressionFormatClass = new AndroidJavaClass("android.graphics.Bitmap$CompressFormat");

                    iconBitmap.Call<bool>("compress", bitmapCompressionFormatClass.GetStatic<AndroidJavaObject>("PNG"), 100, iconByteArrayStream);

                    byte[] iconBytes = iconByteArrayStream.Call<byte[]>("toByteArray");

                    StartCoroutine(AndroidPrepareSharePromptIconThenShare(iconStoreCachePath, iconBytes, message, subject, forceChooseShareApp));   
                } catch (Exception e) {
                    // An exception was encountered, we'll probably share without the app icon instead (unless it was generated successfully in the past?)
                    Debug.LogError("Failed to get app icon! " + e.Message);

                    DoSharePromptAndroid(message, subject, forceChooseShareApp);
                }
            } else {
                Debug.LogError("Android native objects were not ready! Share action failed!");
            }*/
        #elif UNITY_IOS
           DoSharePromptIOS(message, subject, forceChooseShareApp);
        #endif
    }
    
    // Get a reference to the app icon then store it in the application directory so the image path can be sent in a share prompt
    private IEnumerator AndroidPrepareSharePromptIconThenShare(string iconStoreCachePath, byte[] iconBytes, string message, string subject, bool forceChooseShareApp) {
        // Wait a frame just to make sure everything goes smoothly
        yield return null;
        
        File.WriteAllBytes(iconStoreCachePath, iconBytes);
        
        // Wait a frame to give time for the bytes to write
        yield return null;

        if (File.Exists(iconStoreCachePath)) {
            DoSharePromptAndroid(message, subject, forceChooseShareApp, iconStoreCachePath);
        } else {
            DoSharePromptAndroid(message, subject, forceChooseShareApp);
        }
    }

    private void DoSharePromptIOS(string message, string subject, bool doShareAppIcon = false) {
        #if UNITY_EDITOR
            Debug.Log("A share event was triggered! On a iOS device this would trigger system share actions!");
        #elif UNITY_IOS
            // iOS sharing is handled inside Assets/Plugins/iOS/PicklePlugin.mm
            ShowShare(message, subject, doShareAppIcon);
        #endif
    }
    
    // Note: To share an image it must already be saved to an accessible storage location
    private void DoSharePromptAndroid(string message, string subject, bool forceChooseShareApp = true, string imagePath = "") {
        #if UNITY_EDITOR
            Debug.Log("A share event was triggered! On a android device this would trigger system share actions!");
        #elif UNITY_ANDROID
            if (androidObjectsReady){
                try {
                    // Get application intent
                    AndroidJavaClass intentClass = new AndroidJavaClass("android.content.Intent");
                    AndroidJavaObject intentObject = new AndroidJavaObject("android.content.Intent");
                    
                    // Set the action type to ACTION_SEND, this triggers either the default messaging app OR asks the user select a messaging app to use
                    intentObject.Call<AndroidJavaObject>("setAction", intentClass.GetStatic<string>("ACTION_SEND"));
                    
                    // Add extra data named EXTRA_SUBJECT, if the target messaging app uses this then it'll auto fill a field with our subject
                    // (some apps which don't have a subject just prepend this to the message body)
                    intentObject.Call<AndroidJavaObject>("putExtra", intentClass.GetStatic<string>("EXTRA_SUBJECT"), subject);
                    
                    // Add extra data named EXTRA_TEXT, this is usually the main body text but it's up to the messaging app on how this is used
                    intentObject.Call<AndroidJavaObject>("putExtra", intentClass.GetStatic<string>("EXTRA_TEXT"), message);
                    
                    // Set a flag to temporarily grant other apps to read the URI
                    intentObject.Call<AndroidJavaObject>("addFlags", intentClass.GetStatic<int>("FLAG_GRANT_READ_URI_PERMISSION"));
                    
                    if (!string.IsNullOrEmpty(imagePath)) {
                        // Set the image MIME type
                        intentObject.Call<AndroidJavaObject>("setType", "image/png");
                        
                        // Prepare the image we want to send
                        AndroidJavaObject fileObj = new AndroidJavaObject("java.io.File", imagePath);
                        
                        // We're forced to use the fileProvider in android 7+ for handling files between apps
                        AndroidJavaClass fileProviderClass = new AndroidJavaClass("android.support.v4.content.FileProvider");

                        string authority = currentContext.Call<string>("getPackageName") + ".fileprovider";
                        
                        // Prepare our file to be sent to the selected messaging app
                        AndroidJavaObject fileProviderObject = fileProviderClass.CallStatic<AndroidJavaObject>("getUriForFile", currentContext, authority, fileObj);
                        
                        // Add extra data named EXTRA_STREAM, this is a data stream of the image we're attaching
                        intentObject.Call<AndroidJavaObject>("putExtra", intentClass.GetStatic<string>("EXTRA_STREAM"), fileProviderObject);
                    } else {
                        // Set a plain text MIME type
                        intentObject.Call<AndroidJavaObject>("setType", "text/plain");
                    }

                    // When this is true the user is forced into selecting an app to share with rather than using their default messaging app
                    // Note: If the user does not have a default messaging app or has it set to always prompt via settings then they'll be asked to select an app regardless of this setting
                    if (forceChooseShareApp) {
                        // Setup a custom share chooser, this will force ask the player what app they want to use to share with even if they have a default selected app
                        AndroidJavaObject shareChooser = intentClass.CallStatic<AndroidJavaObject>("createChooser", intentObject, "Share Via");
                        
                        // Start the share activity with the share chooser
                        currentActivity.Call("startActivity", shareChooser);
                    } else {
                        // Start the share activity using the default messaging app, or the system default app chooser if a default app isn't set
                        currentActivity.Call("startActivity", intentObject);
                    }
                } catch(Exception e){
                    Debug.LogError("Failed to share! " + e.Message);
                }
            } else {
                Debug.LogError("Android native objects were not ready! Share action failed!");
            }
        #endif
    }

    
}
